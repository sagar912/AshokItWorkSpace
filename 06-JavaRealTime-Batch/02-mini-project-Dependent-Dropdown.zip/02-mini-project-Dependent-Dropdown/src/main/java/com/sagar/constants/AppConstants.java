package com.sagar.constants;

public class AppConstants {
	
	public static final String LOCKED_STR="LOCKED";
	
	public static final Integer TEMP_PWD_LENGTH=6;

	

}
