package com.sagar.controller;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.sagar.entities.UserEntity;
import com.sagar.model.UnlockAccount;
import com.sagar.model.User;
import com.sagar.services.UserService;

@Controller
public class UnlockLoginController {

	@Autowired
	private UserService service;
	// =================================== save changed password and unlock account
	// ========================================//

	@PostMapping(value = { "/unlockAcc" })
	public String unlockUser(@ModelAttribute("unlockAcc") UnlockAccount acc, Model model) {

		System.out.println("Code reached here");
		 User user=new User();
		String newPwd = acc.getTempPwd();
		System.out.println(newPwd);

		 BeanUtils.copyProperties(acc, user);
		try {
			UserEntity userEntity = service.findByuserPwd(newPwd);
							if (newPwd .equals(userEntity.getUserPwd()) ) {
				userEntity.setUserPwd(acc.getNewPwd());
				System.out.println(userEntity);
				}
				// ======================= Set Permanent Password  =======================//

				boolean updateUser = service.updateUser(userEntity);

				if (updateUser == true) {
					model.addAttribute("SuccessMsg", "Your Registration is Successful");
				} else if(updateUser == false ) {
					model.addAttribute("EMsg", "Account is not unlock due to incorrect temp pwd");
					return "unlockUser";

				}
				return "unlockUserSuccess";
			

		

		}catch(Exception e) {
			System.out.println(e.getMessage());
			model.addAttribute("ExMsg", "Account is not unlock due to incorrect temp pwd");

			return "unlockUser";
		}
	
	}
}