package com.sagar.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sagar.entities.UserEntity;
import com.sagar.model.User;
import com.sagar.services.UserService;

@Controller
public class forgotPasswordController {

	@Autowired
	private UserService service;

	private static final Logger logger = LoggerFactory.getLogger(forgotPasswordController.class);

//=====================================================//
	@GetMapping(value = { "/forgotPassword" })
	public String loadForm(User user, Model model) {

		return "forgot";
	}

//=========================================================//	
	@PostMapping(value = { "/forgotPasswords" })
	public String loadForm1(@ModelAttribute("user") User user, Model model) {

		logger.debug("** Method Exexcution Started **");
		try {
			String email = user.getUserEmail();
			UserEntity findByemail = service.findByuserEmail(email);
			String userEmail = findByemail.getUserEmail();
			model.addAttribute("forgotPasswordMsg", "Your Password is sent to your registered email ");
            logger.info("Method Executed Successfully");
		
		} catch (Exception e) {
         logger.error(e.getMessage());
		model.addAttribute("ErrorforgotPasswordMsg", "Entered Email is Wrong... ");
         return "false";
		}
		logger.debug("** Method Exexcution Ended **");
		return "forgot";

	}

}
