package com.sagar.controller;

import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sagar.entities.UserEntity;
import com.sagar.model.UnlockAccount;
import com.sagar.model.User;
import com.sagar.services.UserService;

@Controller
public class RegisterController {

	@Autowired
	private UserService service;

//===============================================Load Form and Set Countries DropDown=================================================//	
	@GetMapping(value = { "/register" })
	public String loadForm(Model model) {
		User user = new User();

		Map<Integer, String> countrieslist = service.getAllCountries();
		model.addAttribute("countries", countrieslist);
		model.addAttribute("user", user);
		return "regUser";
	}

//============================================Set States DropDown =====================================================//	
	@GetMapping(value = { "/getStates" })
	@ResponseBody
	public Map<Integer, String> getStates(@RequestParam("cid") Integer countryId) {

		Map<Integer, String> statesByCountry = service.getStatesByCountry(countryId);
		return statesByCountry;
	}

//================================================ Set City DropDown =================================================//

	@GetMapping(value = { "/getCities" })
	@ResponseBody
	public Map<Integer, String> getCities(@RequestParam("stateid") Integer stateId) {

		Map<Integer, String> citiesByState = service.getCitiesByStates(stateId);
		System.out.println(citiesByState.toString());
		return citiesByState;
	}
//=============================================== Email Validation ====================================================//

	@GetMapping("/validateEmail")
	public @ResponseBody String getEmail(@RequestParam("checkemail") String emailid) {

		String emailexists = service.findEmailByuserEmail(emailid);

		return emailexists;
	}
//=============================================== Save Form ===========================================================//

	@PostMapping(value = { "/userAccReg" })
	public String saveUser(User user, Model model) {
		user.setAccStatus("Locked");
		try {
			
			boolean saveUser = service.saveUser(user);

			System.out.println(saveUser);

			if (saveUser) {
				String SuccessMsg = "Your registration is almost completed.Please check your email to unlock your account";
				model.addAttribute("SuccessMsg", SuccessMsg);
				return "SuccessReg";

			} else {
				model.addAttribute("ErrorMsg", "Something Went Wrong...!!!");
				return null;
			}
			}catch(Exception e) {
			
				e.getMessage();
				return null;
			}
		}
		
	

//=================================================== Unlock Email =====================================================//
	@GetMapping(value = { "/unlockAcc" })
	public String unlockUser(@RequestParam("email") String email, Model model) {
		model.addAttribute("email", email);

		UnlockAccount unlockAcc = new UnlockAccount();
		model.addAttribute("unlockAcc", unlockAcc);

		return "unlockUser";
	}

}
