package com.sagar.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sagar.services.CitizenService;

@RestController
@CrossOrigin(value="http://localhost:4200")
public class ValidateController {

	@Autowired
	private CitizenService citizenService;
	
	@GetMapping(
			value= "/validateSSN/{ssn}/{stateName}"
			//consumes="application/json"
			
			)
	public ResponseEntity<String> validateEmail(@PathVariable("ssn")Long ssn,@PathVariable("stateName")String stateName) throws Exception {
		
		String checkSSN = citizenService.checkSSN(ssn, stateName);
	
		return new ResponseEntity<>(checkSSN, HttpStatus.OK);
	}
}
