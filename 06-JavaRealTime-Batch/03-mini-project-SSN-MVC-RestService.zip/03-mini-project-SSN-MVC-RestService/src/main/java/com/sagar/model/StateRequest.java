package com.sagar.model;

import lombok.Data;

@Data
public class StateRequest {

	private int stateId;
	private String stateName;
}
