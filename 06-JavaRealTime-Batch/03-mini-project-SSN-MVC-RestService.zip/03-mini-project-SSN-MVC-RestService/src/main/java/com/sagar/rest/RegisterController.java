package com.sagar.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.sagar.model.CitizenRequest;
import com.sagar.model.CitizenResponse;
import com.sagar.model.StateRequest;
import com.sagar.services.CitizenService;

@RestController
@CrossOrigin(value="http://localhost:4200")
public class RegisterController {

	@Autowired
	private CitizenService citizenService;



	@PostMapping(
		value = "/register",
		consumes="application/json"

	)
	public ResponseEntity<String> saveForm(@RequestBody CitizenRequest citizen) {

		long ssnSavedEntity = citizenService.ssnEntity(citizen);
		System.out.println(ssnSavedEntity);

		String msg = "Record Saved SuccessFully...!!!";

		return new ResponseEntity<>(msg,HttpStatus.CREATED);

	}
}
