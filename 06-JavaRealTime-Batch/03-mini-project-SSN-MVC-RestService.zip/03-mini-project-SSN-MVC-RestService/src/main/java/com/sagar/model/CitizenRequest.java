package com.sagar.model;

import lombok.Data;

@Data
public class CitizenRequest {

	private String firstName;
	private String lastName;
	private String gender;
	private String dob;
	private String stateName; 
	private Long ssn;

}
