package com.sagar.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sagar.entites.SSNinfoEnity;
import com.sagar.exceptions.NoSSNException;
import com.sagar.model.CitizenRequest;
import com.sagar.model.StateRequest;
import com.sagar.repositories.CitizenRepo;
import com.sagar.repositories.StateRepo;

@Service
public class CitizenServiceImpl implements CitizenService {

	@Autowired
	private CitizenRepo citizenRepo;

	@Autowired
	private StateRepo stateRepo;

	@Override
	public long ssnEntity(CitizenRequest citizen) {

		SSNinfoEnity ssninfoentity = new SSNinfoEnity();

		BeanUtils.copyProperties(citizen, ssninfoentity);

		SSNinfoEnity ssn = citizenRepo.save(ssninfoentity);

		long ssnSaved = ssn.getSsn();

		return ssnSaved;

	}

//====================================//	
	@Override
	public List<StateRequest> getAllStates() {

		List allStatesName = stateRepo.getAllStatesName();

		return allStatesName;
	}
//========================================================================================================================================//

	@Override
	public String checkSSN(Long ssn, String stateName)  {

		SSNinfoEnity ssninfoentity = citizenRepo.findBySsnAndStateName(ssn, stateName);
		if (ssninfoentity != null) {

			return "Valid";

		} else {
			throw new NoSSNException("Non SSN Found in Records");
		}

		}
	}
