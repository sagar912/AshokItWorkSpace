package com.sagar.repositories;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import com.sagar.entites.SSNinfoEnity;


public interface CitizenRepo extends JpaRepository<SSNinfoEnity, Serializable> {
	
	public SSNinfoEnity findBySsnAndStateName(Long ssn,String stateName);

}
