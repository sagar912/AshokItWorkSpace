package com.sagar.model;

import lombok.Data;

@Data
public class CitizenResponse {

	private int citizenId; 
	private String firstName;
	private String lastName;
	private String gender;
	private String dob;
	private String stateName; 
	private int ssn;

}
