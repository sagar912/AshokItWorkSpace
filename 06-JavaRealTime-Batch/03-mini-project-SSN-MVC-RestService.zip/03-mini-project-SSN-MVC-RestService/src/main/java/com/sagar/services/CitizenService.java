package com.sagar.services;

import java.util.List;

import org.springframework.stereotype.Service;
import com.sagar.model.CitizenRequest;
import com.sagar.model.StateRequest;

@Service
public interface CitizenService {
	
	
	public long ssnEntity(CitizenRequest citizen);
	
	public List<StateRequest> getAllStates();
	
	public String checkSSN(Long ssn,String stateName) throws Exception;

}
