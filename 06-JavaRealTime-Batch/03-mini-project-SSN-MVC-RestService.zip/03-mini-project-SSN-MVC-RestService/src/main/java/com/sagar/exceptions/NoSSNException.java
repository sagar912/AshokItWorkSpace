package com.sagar.exceptions;


public class NoSSNException extends RuntimeException {

	/*** **************************************Custom Exception *****************************************/
	private static final long serialVersionUID = 1L;

	public NoSSNException(String message) {

		super(message);
	}

}
